package com.example.s.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.example.s.model.Student;
import com.example.s.repository.StudentRepository;
import com.example.s.service.ExcelExportService;
import com.example.s.service.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@RestController
@RequestMapping("student/api")
public class StudentController {
    @Autowired
    private StudentService studentService;
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private ExcelExportService excelExportService;

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestPart("student") String studentJson,
            @RequestPart("file") MultipartFile file) {
        try {
            // Configure ObjectMapper to handle Java 8 Date/Time types
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

            // Deserialize JSON into Student object
            Student student = objectMapper.readValue(studentJson, Student.class);

            // Handle the uploaded file and set it to the student
            if (file != null && !file.isEmpty()) {
                student.setImage(file.getBytes());
            }

            // Save the student data via the service
            String response = studentService.uploadData(student);
            if ("User Already exists".equals(response)) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to upload student data: " + e.getMessage());
        }
    }

    @GetMapping("/get/{aadhar}")
    public ResponseEntity<?> getStudentById(@PathVariable Long aadhar) {
        try {
            // Retrieve student data using the service
            Student student = studentService.getStudentById(aadhar);

            if (student == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found with ID: " + aadhar);
            }

            // Return the student object as the response
            return ResponseEntity.ok(student);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to retrieve student data: " + e.getMessage());
        }
    }

    @GetMapping("/getall")
    public ResponseEntity<?> getallstudents() {
        List<Student> student = studentService.findAllStudents();
        if (student.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No students are found");
        }
        return ResponseEntity.ok(student);

    }

    @PutMapping("/{aadhar}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long aadhar, @RequestBody Student studentDetails) {
        return studentRepository.findByAadhar(aadhar).map(student -> {
            student.setName(studentDetails.getName());
            student.setEmail(studentDetails.getEmail());
            student.setMobileNumber(studentDetails.getMobileNumber());
            student.setDob(studentDetails.getDob());
            student.setGender(studentDetails.getGender());
            student.setAadhar(studentDetails.getAadhar());
            student.setFatherName(studentDetails.getFatherName());
            student.setMotherName(studentDetails.getMotherName());
            student.setGuardianName(studentDetails.getGuardianName());
            student.setGuardianMobile(studentDetails.getGuardianMobile());
            student.setFatherAadhar(studentDetails.getFatherAadhar());
            student.setMotherAadhar(studentDetails.getMotherAadhar());
            student.setFatherMobileNumber(studentDetails.getFatherMobileNumber());
            student.setMotherMobileNumber(studentDetails.getMotherMobileNumber());
            student.setCaste(studentDetails.getCaste());
            student.setVillage(studentDetails.getVillage());
            student.setMandal(studentDetails.getMandal());
            student.setDistrict(studentDetails.getDistrict());
            student.setPincode(studentDetails.getPincode());
            student.setState(studentDetails.getState());
            student.setHallTicketNumber(studentDetails.getHallTicketNumber());
            student.setSscMarks(studentDetails.getSscMarks());
            student.setSscPercentage(studentDetails.getSscPercentage());
            student.setSchoolName(studentDetails.getSchoolName());
            student.setSchoolAddress(studentDetails.getSchoolAddress());
            student.setSchoolPincode(studentDetails.getSchoolPincode());
            student.setCollegeName(studentDetails.getCollegeName());
            student.setPinNumber(studentDetails.getPinNumber());
            student.setBranch(studentDetails.getBranch());
            student.setPolycetHallTicketNumber(studentDetails.getPolycetHallTicketNumber());
            student.setPolycetRank(studentDetails.getPolycetRank());
            student.setJoiningDate(studentDetails.getJoiningDate());
            student.setCollegeAddress(studentDetails.getCollegeAddress());
            student.setCollegeDistrict(studentDetails.getCollegeDistrict());
            student.setCollegePincode(studentDetails.getCollegePincode());
            return ResponseEntity.ok(studentRepository.save(student));
        }).orElse(ResponseEntity.notFound().build());
    }

    // Delete a student by ID
    @PostMapping("/export")
    public ResponseEntity<byte[]> exportLecturersToExcel(@RequestBody List<String> headers) {
        try {
            // Fetch all lecturers from the database
            List<Student> students = studentRepository.findAll();

            // Convert Lecturer data to a list of maps for dynamic export
            List<Map<String, Object>> data = students.stream().map(lecturer -> {
                Map<String, Object> row = new LinkedHashMap<>();
                for (String header : headers) {
                    switch (header.toLowerCase()) {
                        case "name":
                            row.put(header, lecturer.getName());
                            break;
                        case "email":
                            row.put(header, lecturer.getEmail());
                            break;
                        case "mobile number":
                            row.put(header, lecturer.getMobileNumber());
                            break;
                        case "dob":
                            row.put(header, lecturer.getDob());
                            break;
                        case "gender":
                            row.put(header, lecturer.getGender());
                            break;
                        case "aadhar":
                            row.put(header, lecturer.getAadhar());
                            break;
                        case "father name":
                            row.put(header, lecturer.getFatherName());
                            break;
                        case "mother name":
                            row.put(header, lecturer.getMotherName());
                            break;
                        case "guardian name":
                            row.put(header, lecturer.getGuardianName());
                            break;
                        case "guardian mobile":
                            row.put(header, lecturer.getGuardianMobile());
                            break;
                        case "father aadhar":
                            row.put(header, lecturer.getFatherAadhar());
                            break;
                        case "mother aadhar":
                            row.put(header, lecturer.getMotherAadhar());
                            break;
                        case "father mobile number":
                            row.put(header, lecturer.getFatherMobileNumber());
                            break;
                        case "mother mobile number":
                            row.put(header, lecturer.getMotherMobileNumber());
                            break;
                        case "caste":
                            row.put(header, lecturer.getCaste());
                            break;
                        case "village":
                            row.put(header, lecturer.getVillage());
                            break;
                        case "mandal":
                            row.put(header, lecturer.getMandal());
                            break;
                        case "district":
                            row.put(header, lecturer.getDistrict());
                            break;
                        case "pincode":
                            row.put(header, lecturer.getPincode());
                            break;
                        case "state":
                            row.put(header, lecturer.getState());
                            break;
                        case "hall ticket number":
                            row.put(header, lecturer.getHallTicketNumber());
                            break;
                        case "ssc marks":
                            row.put(header, lecturer.getSscMarks());
                            break;
                        case "ssc percentage":
                            row.put(header, lecturer.getSscPercentage());
                            break;
                        case "school name":
                            row.put(header, lecturer.getSchoolName());
                            break;
                        case "school address":
                            row.put(header, lecturer.getSchoolAddress());
                            break;
                        case "school pincode":
                            row.put(header, lecturer.getSchoolPincode());
                            break;
                        case "college name":
                            row.put(header, lecturer.getCollegeName());
                            break;
                        case "pin number":
                            row.put(header, lecturer.getPinNumber());
                            break;
                        case "branch":
                            row.put(header, lecturer.getBranch());
                            break;
                        case "polycet hall ticket number":
                            row.put(header, lecturer.getPolycetHallTicketNumber());
                            break;
                        case "polycet rank":
                            row.put(header, lecturer.getPolycetRank());
                            break;
                        case "joining date":
                            row.put(header, lecturer.getJoiningDate());
                            break;
                        case "college address":
                            row.put(header, lecturer.getCollegeAddress());
                            break;
                        case "college district":
                            row.put(header, lecturer.getCollegeDistrict());
                            break;
                        case "college pincode":
                            row.put(header, lecturer.getCollegePincode());
                            break;
                        default:
                            row.put(header, "N/A");
                            break;
                    }
                }
                return row;
            }).toList();

            // Generate the Excel file with dynamic headers and data
            byte[] excelFile = excelExportService.exportStudentsToExcel(headers, data);

            // Set HTTP headers for the response
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=students.xlsx");
            responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            // Return the Excel file as a response entity
            return ResponseEntity.ok()
                    .headers(responseHeaders)
                    .body(excelFile);
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
