package com.example.s.Attendence.fourthsem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.s.Attendence.fourthsem.model.FourthSem;
import com.example.s.Attendence.fourthsem.repository.FourthSemRepository;

@Controller
@RequestMapping("api/fourthsem")
public class FourthSemController {

    private final FourthSemRepository fourthSemRepository;

    public FourthSemController(FourthSemRepository fourthSemRepository) {
        this.fourthSemRepository = fourthSemRepository;
    }

    @PutMapping("/postlist")
    public ResponseEntity<String> addAttendance(@RequestBody List<FourthSem> fourthSemList) {
        for (FourthSem student : fourthSemList) {
            Optional<FourthSem> studentOpt = fourthSemRepository.findByPinNumber(student.getPinNumber());

            if (studentOpt.isPresent()) {
                FourthSem existingStudent = studentOpt.get();

                // Update only non-zero attendance fields
                if (student.getDecember() != 0)
                    existingStudent.setDecember(student.getDecember());
                if (student.getJanuary() != 0)
                    existingStudent.setJanuary(student.getJanuary());
                if (student.getFebruary() != 0)
                    existingStudent.setFebruary(student.getFebruary());
                if (student.getMarch() != 0)
                    existingStudent.setMarch(student.getMarch());
                if (student.getApril() != 0)
                    existingStudent.setApril(student.getApril());
                if (student.getMay() != 0)
                    existingStudent.setMay(student.getMay());

                fourthSemRepository.save(existingStudent);
            } else {
                // Save new attendance record
                fourthSemRepository.save(student);
            }
        }

        return ResponseEntity.ok("Attendance successfully submitted for the provided list!");
    }
}
