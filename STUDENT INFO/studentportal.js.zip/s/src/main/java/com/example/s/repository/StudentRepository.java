package com.example.s.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.s.model.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    boolean existsByAadhar(Long aadhar);
    Optional<Student> findByAadhar(Long aadhar);
    boolean existsByPinNumber(String pinNumber); // Keep this method
}
