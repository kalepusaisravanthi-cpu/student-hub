package com.example.s.Attendence.thirdsem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.s.Attendence.thirdsem.model.ThirdSem;

@Repository
public interface ThirdSemRepository extends JpaRepository<ThirdSem,Long> {

    Optional<ThirdSem> findByPinNumber(String pinNumber);
    
}
