package com.example.s.model;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Version;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private Long mobileNumber;
    private LocalDate dob;
    private String gender;
    private Long aadhar;
    private String fatherName;
    private String motherName;
    private String guardianName;
    private Long guardianMobile;
    private Long fatherAadhar;
    private Long motherAadhar;
    private Long fatherMobileNumber;
    private Long motherMobileNumber;
    private String caste;
    private String village;
    private String mandal;
    private String district;
    private int pincode;
    private String state;
    private Long hallTicketNumber;
    private int sscMarks;
    private int sscPercentage;
    private String schoolName;
    private String schoolAddress;
    private int schoolPincode;
    private String collegeName;
    private String pinNumber;
    private String branch;
    private Long polycetHallTicketNumber;
    private Long polycetRank;
    private LocalDate joiningDate;
    private String collegeAddress;
    private String collegeDistrict;
    private Long collegePincode;
    private String year;
    private int shift;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    @Lob
    private byte[] image;

    // Getter and Setter for the image
    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(Long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Long getAadhar() {
        return aadhar;
    }

    public void setAadhar(Long aadhar) {
        this.aadhar = aadhar;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getGuardianName() {
        return guardianName;
    }

    public void setGuardianName(String guardianName) {
        this.guardianName = guardianName;
    }

    public Long getGuardianMobile() {
        return guardianMobile;
    }

    public void setGuardianMobile(Long guardianMobile) {
        this.guardianMobile = guardianMobile;
    }

    public Long getFatherAadhar() {
        return fatherAadhar;
    }

    public void setFatherAadhar(Long fatherAadhar) {
        this.fatherAadhar = fatherAadhar;
    }

    public Long getMotherAadhar() {
        return motherAadhar;
    }

    public void setMotherAadhar(Long motherAadhar) {
        this.motherAadhar = motherAadhar;
    }

    public Long getFatherMobileNumber() {
        return fatherMobileNumber;
    }

    public void setFatherMobileNumber(Long fatherMobileNumber) {
        this.fatherMobileNumber = fatherMobileNumber;
    }

    public Long getMotherMobileNumber() {
        return motherMobileNumber;
    }

    public void setMotherMobileNumber(Long motherMobileNumber) {
        this.motherMobileNumber = motherMobileNumber;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getMandal() {
        return mandal;
    }

    public void setMandal(String mandal) {
        this.mandal = mandal;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Long getHallTicketNumber() {
        return hallTicketNumber;
    }

    public void setHallTicketNumber(Long hallTicketNumber) {
        this.hallTicketNumber = hallTicketNumber;
    }

    public int getSscMarks() {
        return sscMarks;
    }

    public void setSscMarks(int sscMarks) {
        this.sscMarks = sscMarks;
    }

    public int getSscPercentage() {
        return sscPercentage;
    }

    public void setSscPercentage(int sscPercentage) {
        this.sscPercentage = sscPercentage;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getSchoolAddress() {
        return schoolAddress;
    }

    public void setSchoolAddress(String schoolAddress) {
        this.schoolAddress = schoolAddress;
    }

    public int getSchoolPincode() {
        return schoolPincode;
    }

    public void setSchoolPincode(int schoolPincode) {
        this.schoolPincode = schoolPincode;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getPinNumber() {
        return pinNumber;
    }

    public void setPinNumber(String pinNumber) {
        this.pinNumber = pinNumber;
    }

    public Long getPolycetHallTicketNumber() {
        return polycetHallTicketNumber;
    }

    public void setPolycetHallTicketNumber(Long polycetHallTicketNumber) {
        this.polycetHallTicketNumber = polycetHallTicketNumber;
    }

    public Long getPolycetRank() {
        return polycetRank;
    }

    public void setPolycetRank(Long polycetRank) {
        this.polycetRank = polycetRank;
    }

    public LocalDate getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(LocalDate joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getCollegeAddress() {
        return collegeAddress;
    }

    public void setCollegeAddress(String collegeAddress) {
        this.collegeAddress = collegeAddress;
    }

    public String getCollegeDistrict() {
        return collegeDistrict;
    }

    public void setCollegeDistrict(String collegeDistrict) {
        this.collegeDistrict = collegeDistrict;
    }

    public Long getCollegePincode() {
        return collegePincode;
    }

    public void setCollegePincode(Long collegePincode) {
        this.collegePincode = collegePincode;
    }

}
