package com.example.s.Attendence.fourthsem.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.s.Attendence.fourthsem.model.FourthSem;

public interface FourthSemRepository extends JpaRepository<FourthSem, Long> {
    Optional<FourthSem> findByPinNumber(String pinNumber);
}
