package com.example.s.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.s.model.Student;
import com.example.s.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public String uploadData(Student student) {
        if (doesUserExistByAadhar(student.getAadhar()) || doesUserExistByPinNumber(student.getPinNumber())) {
            return "User already exists";
        }

        studentRepository.save(student);
        return "User upload successful";
    }

    private boolean doesUserExistByPinNumber(String pinNumber) {
        return studentRepository.existsByPinNumber(pinNumber);
    }

    private boolean doesUserExistByAadhar(Long aadhar) {
        return studentRepository.existsByAadhar(aadhar);
    }

    public Student getStudentById(Long aadhar) {
        return studentRepository.findByAadhar(aadhar)
                .orElseThrow(() -> new RuntimeException("Student not found with Aadhar: " + aadhar));
    }

    public List<Student> findAllStudents() {
        return studentRepository.findAll();
    }
}
