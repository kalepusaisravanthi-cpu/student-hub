package com.example.s.Registration;


import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailRepository extends JpaRepository<Email, Long> {
    // You can add custom query methods here if needed
    boolean existsByEmail(String email);
}
