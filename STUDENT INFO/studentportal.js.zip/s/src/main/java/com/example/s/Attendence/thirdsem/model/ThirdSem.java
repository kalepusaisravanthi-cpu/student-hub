package com.example.s.Attendence.thirdsem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class ThirdSem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String pinNumber;
    private int june;
    private int july;
    private int august;
    private int september;
    private int october;
    private int november;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPinNumber() {
        return pinNumber;
    }
    public void setPinNumber(String pinNumber) {
        this.pinNumber = pinNumber;
    }
    public int getJune() {
        return june;
    }
    public void setJune(int june) {
        this.june = june;
    }
    public int getJuly() {
        return july;
    }
    public void setJuly(int july) {
        this.july = july;
    }
    public int getAugust() {
        return august;
    }
    public void setAugust(int august) {
        this.august = august;
    }
    public int getSeptember() {
        return september;
    }
    public void setSeptember(int september) {
        this.september = september;
    }
    public int getOctober() {
        return october;
    }
    public void setOctober(int october) {
        this.october = october;
    }
    public int getNovember() {
        return november;
    }
    public void setNovember(int november) {
        this.november = november;
    }
   
}