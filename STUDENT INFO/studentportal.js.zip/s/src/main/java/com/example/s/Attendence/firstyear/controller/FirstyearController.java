package com.example.s.Attendence.firstyear.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.s.Attendence.firstyear.model.Firstyear;
import com.example.s.Attendence.firstyear.repository.FirstyearRepository;

@RestController
@RequestMapping("api/firstyear")
public class FirstyearController {
    @Autowired
    private FirstyearRepository firstyearRepository;

    
    @GetMapping("/get")
    public ResponseEntity<List<Firstyear>> getAllAttendance() {
        List<Firstyear> firstyearList = firstyearRepository.findAll();
        return ResponseEntity.ok(firstyearList);
    }

    @PutMapping("/postlist")
    public ResponseEntity<String> addAttendance(@RequestBody List<Firstyear> firstyearList) {
        for (Firstyear firstyear : firstyearList) {
            Optional<Firstyear> studentOpt = firstyearRepository.findBypinNumber(firstyear.getPinNumber());

            if (studentOpt.isPresent()) {
                Firstyear existingStudent = studentOpt.get();

                // Update only non-zero attendance fields

                if (firstyear.getJune() != 0)
                    existingStudent.setJune(firstyear.getJune());
                if (firstyear.getJuly() != 0)
                    existingStudent.setJuly(firstyear.getJuly());
                if (firstyear.getAugust() != 0)
                    existingStudent.setAugust(firstyear.getAugust());
                if (firstyear.getSeptember() != 0)
                    existingStudent.setSeptember(firstyear.getSeptember());
                if (firstyear.getOctober() != 0)
                    existingStudent.setOctober(firstyear.getOctober());
                if (firstyear.getNovember() != 0)
                    existingStudent.setNovember(firstyear.getNovember());
                if (firstyear.getDecember() != 0)
                    existingStudent.setDecember(firstyear.getDecember());
                if (firstyear.getJanuary() != 0)
                    existingStudent.setJanuary(firstyear.getJanuary());
                if (firstyear.getFebruary() != 0)
                    existingStudent.setFebruary(firstyear.getFebruary());
                if (firstyear.getMarch() != 0)
                    existingStudent.setMarch(firstyear.getMarch());
                if (firstyear.getApril() != 0)
                    existingStudent.setApril(firstyear.getApril());
                if (firstyear.getMay() != 0)
                    existingStudent.setMay(firstyear.getMay());

                firstyearRepository.save(existingStudent);
            } else {
                // Save new attendance record
                firstyearRepository.save(firstyear);
            }
        }

        return ResponseEntity.ok("Attendance successfully submitted for the provided list!");
    }

}