package com.example.s.Attendence.fifthsem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.s.Attendence.fifthsem.model.FifthSem;
import com.example.s.Attendence.fifthsem.repository.FifthSemRepository;

@Controller
@RequestMapping("api/fifthsem")
public class FifthSemController {

    private final FifthSemRepository fifthSemRepository;

    public FifthSemController(FifthSemRepository fifthSemRepository) {
        this.fifthSemRepository = fifthSemRepository;
    }

    @PutMapping("/postlist")
    public ResponseEntity<String> addAttendance(@RequestBody List<FifthSem> fifthSemList) {
        for (FifthSem student : fifthSemList) {
            Optional<FifthSem> studentOpt = fifthSemRepository.findByPinNumber(student.getPinNumber());

            if (studentOpt.isPresent()) {
                FifthSem existingStudent = studentOpt.get();

                // Update only non-zero attendance fields
                if (student.getJanuary() != 0) existingStudent.setJanuary(student.getJanuary());
                if (student.getFebruary() != 0) existingStudent.setFebruary(student.getFebruary());
                if (student.getMarch() != 0) existingStudent.setMarch(student.getMarch());
                if (student.getApril() != 0) existingStudent.setApril(student.getApril());
                if (student.getMay() != 0) existingStudent.setMay(student.getMay());
                if (student.getJune() != 0) existingStudent.setJune(student.getJune());
                if (student.getJuly() != 0) existingStudent.setJuly(student.getJuly());
                if (student.getAugust() != 0) existingStudent.setAugust(student.getAugust());
                if (student.getSeptember() != 0) existingStudent.setSeptember(student.getSeptember());
                if (student.getOctober() != 0) existingStudent.setOctober(student.getOctober());
                if (student.getNovember() != 0) existingStudent.setNovember(student.getNovember());
                if (student.getDecember() != 0) existingStudent.setDecember(student.getDecember());

                fifthSemRepository.save(existingStudent);
            } else {
                // Save new attendance record
                fifthSemRepository.save(student);
            }
        }

        return ResponseEntity.ok("Attendance successfully submitted for the provided list!");
    }
}
