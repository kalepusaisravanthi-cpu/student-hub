package com.example.s.Registration;



import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class EmailController {

    @Autowired
    private EmailRepository userRepository;

    @Autowired
    private EmailService emailService;
    private Map<String, String> otpStore = new HashMap<>();

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody Email user) {
        // Save user to the database
        userRepository.save(user);
        
        // Send OTP to user's email
        String otp = emailService.sendOtp(user.getEmail());
        otpStore.put(user.getEmail(), otp);
        
        return ResponseEntity.ok("An OTP has been sent to your email.");
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestBody Email user) {//@RequestParam String email, @RequestParam String otp
        String storedOtp = otpStore.get(user.getEmail());
        if (storedOtp != null && storedOtp.equals(user.getOtp())) {
            otpStore.remove(user.getEmail());
            return ResponseEntity.ok("OTP verified successfully!");
        }
        return ResponseEntity.badRequest().body("Invalid OTP.");
    }

    @PostMapping("/verify-email")
    public ResponseEntity<String> verifyEmail(@RequestParam String email) {
        boolean emailSent = emailService.sendVerificationEmail(email);
        if (emailSent) {
            return ResponseEntity.ok("Verification email sent.");
        } else {
            return ResponseEntity.badRequest().body("Failed to send email. Please check the address.");
        }
    }
}

