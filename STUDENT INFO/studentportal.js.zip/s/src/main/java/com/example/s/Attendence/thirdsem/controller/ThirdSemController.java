package com.example.s.Attendence.thirdsem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.s.Attendence.thirdsem.model.ThirdSem;
import com.example.s.Attendence.thirdsem.repository.ThirdSemRepository;

@Controller
@RequestMapping("api/thirdsem")
public class ThirdSemController {

    private  ThirdSemRepository thirdSemRepository;

    // Constructor for dependency injection
    public ThirdSemController(ThirdSemRepository thirdSemRepository) {
        this.thirdSemRepository = thirdSemRepository;
    }

    @PutMapping("/postlist")
    public ResponseEntity<String> addAttendance(@RequestBody List<ThirdSem> thirdSemList) {
        for (ThirdSem thirdSem : thirdSemList) {
            Optional<ThirdSem> studentOpt = thirdSemRepository.findByPinNumber(thirdSem.getPinNumber());

            if (studentOpt.isPresent()) {
                ThirdSem existingStudent = studentOpt.get();

                // Update only non-zero attendance fields
                if (thirdSem.getJuly() != 0)
                    existingStudent.setJuly(thirdSem.getJuly());
                if (thirdSem.getAugust() != 0)
                    existingStudent.setAugust(thirdSem.getAugust());
                if (thirdSem.getSeptember() != 0)
                    existingStudent.setSeptember(thirdSem.getSeptember());
                if (thirdSem.getOctober() != 0)
                    existingStudent.setOctober(thirdSem.getOctober());
                if (thirdSem.getNovember() != 0)
                    existingStudent.setNovember(thirdSem.getNovember());
                if (thirdSem.getJune() != 0)
                    existingStudent.setJune(thirdSem.getJune());

                thirdSemRepository.save(existingStudent);
            } else {
                // Save new attendance record
                thirdSemRepository.save(thirdSem);
            }
        }

        return ResponseEntity.ok("Attendance successfully submitted for the Third Semester list!");
    }
}
