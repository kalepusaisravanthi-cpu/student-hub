package com.example.s.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.s.model.Lecturer;

public interface LecturerRepository extends JpaRepository<Lecturer, Long> {
}
