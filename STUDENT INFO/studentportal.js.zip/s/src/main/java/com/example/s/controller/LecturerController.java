package com.example.s.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.s.model.Lecturer;
import com.example.s.service.LecturerService;

import java.util.List;

@RestController
@RequestMapping("/lecturers")
@CrossOrigin(origins = "http://localhost:3000") // Allow requests from React app
public class LecturerController {

    @Autowired
    private LecturerService lecturerService;

    @PostMapping("/register")
    public Lecturer createLecturer(@RequestBody Lecturer lecturer) {
        return lecturerService.saveLecturer(lecturer);
    }

    @GetMapping
    public List<Lecturer> getAllLecturers() {
        return lecturerService.getAllLecturers();
    }

    @DeleteMapping("/{id}")
    public void deleteLecturer(@PathVariable Long id) {
        lecturerService.deleteLecturer(id);
    }
}
